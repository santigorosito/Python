import setuptools

setuptools.setup(
    name="paquete1",
    version="1.0",
    description="Pagina web de python",
    author="Santiago Gorosito",
    author_email="santigrst@gmail.com",
)